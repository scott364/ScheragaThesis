

class KeyframeLFDModel():
    """
    Used to represent a learned keyframe LfD model.  
    """
    
    def __init__(self):
        pass

    def import_model(self, config_file, demonstration_directory):
        pass
    
    