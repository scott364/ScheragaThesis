#!/bin/bash
rosrun xacro xacro sawyer.urdf.xacro > sawyer_static.urdf
